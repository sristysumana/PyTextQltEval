# examples/run_analysis.py
from doc_quality.metrics import get_metrics
from doc_quality.suggestions import suggest_improvements

if __name__ == "__main__":
    with open("sample_text.txt", "r") as f:
        content = f.read()

    metrics = get_metrics(content)
    feedback = suggest_improvements(metrics)

    print("=== METRIC SCORES ===")
    for k, v in metrics.items():
        print(f"{k}: {v}")

    print("\n=== SUGGESTIONS ===")
    for s in feedback:
        print(f"- {s}")
