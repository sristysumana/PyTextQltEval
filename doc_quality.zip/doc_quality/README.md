# 📘 doc_quality

`doc_quality` is a Python library designed to evaluate the quality of software documentation, including README files and release notes. It applies 14 interpretable metrics across six key documentation attributes:

- ✂️ Conciseness
- 📖 Readability
- 🧩 Consistency
- 🧱 Structuredness
- 🔗 Traceability
- 🧠 Cohesion

The goal is to help developers and teams write clearer, more maintainable, and standardized documentation.

---

## 🔍 Features

- Analyze documentation with 14 text quality metrics.
- Automatically generate improvement suggestions.
- Evaluate both markdown and plain-text formats.
- Useful for static analysis, CI/CD pipelines, and research.

---

## 📦 Installation

```bash
pip install doc_quality

---

## 📦 Usage
import doc_quality as analyzer

# Load your documentation file
with open("README.md", "r", encoding="utf-8") as f:
    text = f.read()

# Get scores and suggestions
scores = analyzer.get_metrics(text)
suggestions = analyzer.suggest_improvements(scores)

print("\n--- Metrics ---")
for k, v in scores.items():
    print(f"{k}: {v}")

print("\n--- Suggestions ---")
for s in suggestions:
    print(f"- {s}")

